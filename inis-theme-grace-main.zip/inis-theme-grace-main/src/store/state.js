export default {
    login: {
        is_login: false
    },
    head_cover: "",
    send_talk: false,
    music: {
        is_play: false,
        music_info: {},
        volume: 0.7,
    },
    music_control: {
        duration: 0.00,
        currentTime: 0.00,
    },
    music_progress: {
        ended: false,
    }
    
}